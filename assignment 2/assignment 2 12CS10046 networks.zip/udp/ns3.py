import re
import sys
import string

filename = raw_input("Enter filename \n")
file_read = open(filename + ".tr", 'r')
file_write = open(filename + ".txt",'w')
file_write.write("\t\t\t\t\tDETAILS OF FILE \t"+filename+"\n\n")
s = file_read.readlines()

l = []
i = 0
for line in s:
	l.append(line.split(" "))

l_enqueue = []
l_dequeue = []
l_received = [] 
l_dropped = [] 
for i in range(len(l)):
	if(l[i][0] == '+' and "ns3::UdpHeader" in l[i]):
		l_enqueue.append(l[i])
		

	elif(l[i][0] == '-' and "ns3::UdpHeader" in l[i]):
		l_dequeue.append(l[i])
		

	elif(l[i][0] == 'r' and "ns3::UdpHeader" in l[i]):
		l_received.append(l[i])
		

	elif(l[i][0] == 'd' and "ns3::UdpHeader" in l[i]):
		l_dropped.append(l[i])
		



s1 = "1)\ttimeFirstTPacket: when the first packet in the flow was transmitted; " + l_enqueue[0][1] + "\n\n"
s2 = "2)\ttimeLastTPacket: when the last packet in the flow was transmitted; " + l_enqueue[-1][1] + "\n\n"

s3 = "3)\ttimeFirstRPacket: when the first packet in the flow was received by an end node; " + l_received[0][1] + "\n\n"
s4 = "4)\ttimeLastRPacket: when the last packet in the flow was received; " + l_received[-1][1] + "\n\n"
a = 0
c = 0
for i in range(len(l_enqueue)):
	b = l_enqueue[i].index("Payload") + 1
	result = re.findall(r'[0-9]+', l_enqueue[i][b])
	a = a + int(result[0])
	c = c + 1

trans = a
s5 = "6)\ttBytes, tPackets: total number of transmitted bytes / packets for the flow; " + str(a) + " / " + str(c) + "\n\n"

a = 0
c = 0
for i in range(len(l_received)):
	b = l_received[i].index("Payload") + 1
	result = re.findall(r'[0-9]+', l_received[i][b])
	a = a + int(result[0])
	c = c + 1

recei = a
s6 = "7)\trBytes, rPackets: total number of received bytes / packets for the flow; " + str(a) + " / " + str(c) + "\n\n"


s7 = "10)\tpacketsDropped, bytesDropped: the number of lost packets and bytes. " + str(len(l_dropped)) + "\n\n"

a = float(l_received[-1][1])
a = a - 2

s8 = "11)\ttransmitterThroughput : the throughput of the transmitter, calculated as amount of bytes transmitted divided by total time  " + str(trans/a) + "\n\n"
s9 = "12)\trecieverThroughput : the throughput of the receiver, calculated as amount of bytes received divided by total time " + str(recei/a) + "\n\n"

count = 0
for i in range(len(l_enqueue)):
	a = l_enqueue[i].index("id")
	b = l_enqueue[i][a+1]
	c = l_enqueue[i].index("ns3::UdpHeader")
	d = l_enqueue[i][c-1]
	t1 = l_enqueue[i][1]
	for j in range(len(l_received)):
		e = l_received[j].index("id")
		f = l_received[j][e+1]
		g = l_received[j].index("ns3::UdpHeader")
		h = l_received[j][g-1]
		t2 = l_received[j][1]
		if( b == f and d == h ):
			count = count + float(t2) - float(t1)

s10 = "5)\tdelaySum: the sum of all end-to-end delays for all received packets of the flow; " + str(count) + "\n\n"


count = 0
for i in range(len(l_enqueue)):
	a = l_enqueue[i].index("id")
	b = l_enqueue[i][a+1]
	c = l_enqueue[i].index("ns3::UdpHeader")
	d = l_enqueue[i][c-1]
	flag = 0
	for j in range(len(l_received)):
		e = l_received[j].index("id")
		f = l_received[j][e+1]
		g = l_received[j].index("ns3::UdpHeader")
		h = l_received[j][g-1]
		if( b == f and d == h ):
			flag = 1

	if flag == 0:
		count += 1

s11 = "8)\tlostPackets: total number of packets that are assumed to be lost (not reported over 10 seconds); " + str(count) + "\n\n"


s12 = "9)"
for i in range(len(l_enqueue)):
	a = l_enqueue[i].index("id")
	b = l_enqueue[i][a+1]
	c = l_enqueue[i].index("ns3::UdpHeader")
	d = l_enqueue[i][c-3] + " " + l_enqueue[i][c-2] + " " + l_enqueue[i][c-1]
	count = 0
	for j in range(len(l_dequeue)):
		e = l_dequeue[j].index("id")
		f = l_dequeue[j][e+1]
		g = l_dequeue[j].index("ns3::UdpHeader")
		h = l_dequeue[j][g-3] + " " + l_dequeue[j][g-2] + " " + l_dequeue[j][g-1]
		if( b == f and d == h ):
			count += 1

	s12 = s12 + "\tNumber of times Package with id = " + b + " and ip address " + d + " is forwarded is =  " + str(count) + "\n"
s12 = s12 + "\n"

file_write.write(s1)
file_write.write(s2)
file_write.write(s3)
file_write.write(s4)
file_write.write(s10)
file_write.write(s5)
file_write.write(s6)
file_write.write(s11)
file_write.write(s12)
file_write.write(s7)
file_write.write(s8)
file_write.write(s9)
file_write.close()
file_read.close()